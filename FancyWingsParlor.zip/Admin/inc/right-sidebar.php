<div class="col-sm-2">
  <div class="card border-dark">
    <div class="card-header bg-primary">
      <strong>Back Control</strong>
    </div>
    <div class="card-header">
      <h6><a class="text-dark" target="blank" href="../../index.php">Visite Site</a></h6>
    </div>

  </div>
</div>
</div>
</div>
</section>