#Before start the project

1. install xampp

   #Project install process..
2. past the unzip folder C:\xampp\htdocs\
3. create database name = parlor
4. import sql file in your database
5. Open xampp and start mysql and apache
6. Open a browser and past the url http://localhost/parlor
   7.For Admin Dashboard http://localhost/parlor/admin
   (usename: parlor & password 12356789)
7. Finally enjoy and implement the project for your requirement

#Working History

 #Frontend View
1. homepage contact form submit
2. homepage appointment form submit
3. Service (crud) create, read, update, delete
4. dynamic basic web content

#Admim Dashboard
1. Apintment list and delete process
2. Contact message list and delete process
3. Service Crud(Create, read, Update, delete)
4. Basic settings read & Update

